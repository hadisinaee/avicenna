---
title: "Projects"
date: 2020-10-20T18:55:12+03:30
headless: true
weight: 2
content_type: "projects"

section_settings:
    show_section: true
    title: ''
    subtitle: 'see my github for the complete list'
---

project  content