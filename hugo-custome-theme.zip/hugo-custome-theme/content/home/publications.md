---
title: "Publications"
date: 2020-10-20T18:55:12+03:30
headless: true
weight: 1

content_type: 'publications'
section_settings:
    show_section: true
    title: 'Recent Publications'
    subtitle: 'see my google scholar for the latest list'
    
---

home/publications.md