---
title: "about"
date: 2020-10-20T17:51:47+03:30
draft: true
headless: true

full_name: "Hadi Sinaee"
profile_picture: "profile.png"

socials:
    twitter: "HadiSinaee"
    github: "hadisinaee"
    facebook: "hadisinaee"
    twitch: "hadisinaee"
    google_scholar: "hadisinaee"

interests:
    - Data Intensive Systems
    - Distributed Systems
    - Data Streaming Platforms
    - Large-Scale Data Processing Platforms

affiliations:
    - affiliation:
        title: "Ph.D. Track"
        name: "University of British Columbia"
        email: "sinaee@cs.ubc.ca"
    - affiliation:
        title: "CEO & Co-Founder"
        name: "The Coolest Startup In the World"
        email: "sinaee@mycoolstartup.ai"

academia:
    - course:
        degree: "Ph.D. Track"
        institution:  "University of British Columbia"
        major: "Systems"
        start_date: "2021"
    - course:
        degree: "M.Sc."
        institution: 'Sharif University of Technology'
        major: 'Artificial Intelligence'
        supervisor: 'Prof. A'
        start_date: '2013'
        end_date: '2016'
        other_info: 'graduated with first class honor'
    - course:
        degree: "B.Sc."
        institution: 'University of Kashan'
        major: 'Software Engineering'
        minor: 'Statistics'
        start_date: '2009'
        end_date: '2013'
        other_info: 'graduated with first class honor, supervised by Prof. B'
---

I co-founded HodHod Messenger, an instant messaging application, which was funded by four prominent VCs in Tehran,Iran. Currently, I’m working as a CTO and Director of Product at Ostadkar.pro, the largest online platform for home services in Iran. I spent about three years as a data engineer and scientist in the industry.

Previously, I received my M.Sc in Artificial Intelligence from Sharif University of Technology, Tehran, Iran. My research focused on Machine Learning, specifically Deep Learning. I applied Deep Learning on sensory data for human behavior prediction in smart homes under supervision of Prof. Mahdieh Soleymani Baghshah.