---
title: "An Example Article Name"
authors:
- Hadi Sinaee
- Another Researcher
date: "2018-09-01"

publication: "Journal of Machine Learning"
publication_short: "JMLR"

abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed ac faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis sapien eu, pulvinar tempor diam. Quisque risus orci, mollis id ante sit amet, gravida egestas nisl. Sed ac tempus magna. Proin in dui enim. Donec condimentum, sem id dapibus fringilla, tellus enim condimentum arcu, nec volutpat est felis vel metus. Vestibulum sit amet erat at nulla eleifend gravida.

links:
    url_pdf: http://arxiv.org/pdf/1512.04133v1
    url_code: 'code'
    url_dataset: 'dataset'
    url_poster: 'poster'
    url_project: 'project'
    url_slides: 'slides'
    url_source: 'source'
    url_video: 'video'

# Set an image associated with for your publication.
# e.g: image_url: 'Image credit: [**Unsplash**](https://unsplash.com/photos/jdD8gXaTZsc)'
image_url: ''
---

