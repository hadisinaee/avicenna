---
title: "Prettier Zap: beautify and query zap logger outputs"

date: "2018-05-18"

summary: in simple terms, it pretty prints zap logs and let you query them.

links:
    git: 'https://github.com/hadisinaee/pz'
    # custom_link: 'asfhdsfa'
---

