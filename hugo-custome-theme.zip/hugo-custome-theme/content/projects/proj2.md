---
title: "System Design Premiere: a translation of system design interview questions in persian"

date: "2019-03-30"

summary: 

links:
    git: 'https://github.com/hadisinaee/system-design-primer/blob/persian-translation/README-fa.md'
    # custom_link: 'asfhdsfa'
---

